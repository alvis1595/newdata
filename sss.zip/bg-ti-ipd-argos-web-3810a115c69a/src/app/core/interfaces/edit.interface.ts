export interface editForm {
  url: string;
  action: string;
  description: string;
  title?: string;
  key?: string;
}
