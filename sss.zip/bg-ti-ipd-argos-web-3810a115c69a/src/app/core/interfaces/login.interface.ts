export interface login {
  domain_user: string ;
  domain_passwd: string ;
}
