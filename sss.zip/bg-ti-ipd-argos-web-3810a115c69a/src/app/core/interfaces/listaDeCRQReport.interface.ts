export interface ListaDeCRQReport {
  varCambio2: String;
  varFechaDeSalida: string;
  varDescripcion: string;
  varBeneficio: string;
  varSolicitante      : string;
  varImplementador: string;
  varProducto: string;
  varEstado: string;
}
