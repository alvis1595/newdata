export interface Credential {
  id: string;
  type: string;
  usuario: string;
  password: string;
  timeinicio: string;
  tiempofinal: string;
}
