export interface cat {
  ct_crq_number: string
  pp_jenkins_jobname: string
  ct_crq_deploy_date: string
  cm_artifact_name: string
  pt_executor: string
  en_env_descripcion: string
  se_name: string
  st_descripcion: string
}
