export interface Capa {
    cc_id:       number;
    nombre:      string;
    descripcion: string;
}
