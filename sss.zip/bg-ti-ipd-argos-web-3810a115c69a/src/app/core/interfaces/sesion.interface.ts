export interface sesion {
  roles: string;
  token: string;
}
