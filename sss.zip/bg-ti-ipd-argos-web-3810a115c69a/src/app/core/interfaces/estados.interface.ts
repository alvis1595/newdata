export interface servicio {
  ape_id: string
  aplicacion: string
}
