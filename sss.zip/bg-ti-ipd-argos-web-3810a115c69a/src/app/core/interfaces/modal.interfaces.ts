export interface ModalInterface {
  refresh: boolean;
  title?: string;
  descripcion?: string;
  type?: string;
}
